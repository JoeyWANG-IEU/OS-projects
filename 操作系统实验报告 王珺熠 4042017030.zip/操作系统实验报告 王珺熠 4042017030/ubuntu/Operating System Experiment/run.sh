./experiment.o $@
