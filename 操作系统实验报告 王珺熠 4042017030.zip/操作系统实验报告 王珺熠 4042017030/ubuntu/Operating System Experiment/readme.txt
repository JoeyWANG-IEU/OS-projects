操作步骤：
	1)使用ubuntu自带的c语言编译器(gcc)，程序名称experiment
	2)输入./compile.sh,对源程序进行编译.
	3)输入./run.sh +选择条件，运行程序.

