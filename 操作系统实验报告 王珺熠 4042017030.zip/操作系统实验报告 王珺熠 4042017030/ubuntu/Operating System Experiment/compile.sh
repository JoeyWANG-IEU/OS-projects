gcc experiment.c -o experiment

