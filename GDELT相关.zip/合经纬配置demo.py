import csv
import sys
import os

Cameo = {}
num_cameo = []
a = 0
file = 'name.txt'
fn = open(file,"r")
for row in fn.readlines():
    row = row.split()
    Cameo[row[0]]=a
    num_cameo.append(row[0])
    a += 1

fn.close()

file = 'jingwei.csv'
fn = open(file,"r")
reader = csv.reader(fn)
## 250国家代码映射经纬度字典
cameo_jw = {}
a=0
for row in reader:
    if a==0:
        a+=1
        continue
    cameo_jw[row[0]]=[row[1],row[2]]
fn.close()

## name序号对应经纬度字典，国际类组织没有，不在num_jw.keys()中
num_jw = {}
for i in range(len(num_cameo)):
    if num_cameo[i] in num_jw.keys():
        num_jw[i]=cameo_jw[num_cameo[i]]

        
        

