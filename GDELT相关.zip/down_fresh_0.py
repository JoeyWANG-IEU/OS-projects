
import requests
import zipfile
import csv


date="20191104"
###history
start = input("input start date")
end = input ("input end data")
start = (int)(start)
end = (int)(end)

for ii in range(start,end):  #左开右闭
    print(ii)
    date = (str)(ii) #日期由int型转换成字符串
    #print(date)
    name0 = date+".export.CSV"
    name = date+".export.CSV.zip"
    addr = "http://data.gdeltproject.org/events/"+ name#定位到网页链接
    f = requests.get(addr)#向服务器发送请求
    with open(name,'wb') as code:#以二进制写方式打开，只能写文件， 如果文件不存在，创建该文件；如果文件已存在，先清空，再打开文件，文件名是name
        code.write(f.content)#f.content是字节方式的响应体，会自动解码 gzip 和 deflate 压缩，将f.content写入
    f = zipfile.ZipFile(name)#创建一个ZipFile对象，表示一个zip文件。默认值为'r'，表示读已经存在的zip文件。
    for file in f.namelist():#f.namelist()返回列表，列表中的元素为压缩文件中的每个文件
        f.extract(file,"./data/")#循环访问该压缩文件中的文件，并且一个一个file的解压到对应的"./data/"文件夹中

    path = "./data/" + name0
    file = open(path, "r")
    reader = csv.reader(file)

    event = []
    for row in reader:
        # every row
        event.append(row)

    new_event = []
    for ii in range(len(event)):
        temp_event = []
        for jj in range(len(event[ii])):
            temp_event += event[ii][jj].split('\t')
        new_event.append(temp_event)

        new_name = "n_" + name0
        path = "./n_data/" + new_name
        fn = open(path, "w", newline='')
        writer = csv.writer(fn)

        for ii in range(len(new_event)):
            writer.writerow(new_event[ii])
            #print(ii)
        fn.close()
    print("DOWNLOAD FINISHED")

