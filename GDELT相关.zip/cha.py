import sys
import os
import csv
#某日所有数据，统计出发生在各地区的新闻数量
Cameo = {}#字符串
num_cameo = []#创建空列表，数组
a = 0
file = 'name.txt'
fn = open(file,"r")
for row in fn.readlines():
    row = row.split()#对name里面字符串分片
    Cameo[row[0]]=a#初始化列表第一个值AFR为零
    num_cameo.append(row[0])#数据加入字典
    a += 1
fn.close()#关闭文件

date = input("input date")
name = "n_" + date+ ".export.CSV"

event = []
f = open("I:/code/n_data/"+name,"r")
reader = csv.reader(f)
for row in reader:
    event.append(row)
f.close()

##############
#查询

event_num = {}
for ii in range(len(num_cameo)):#计数num_cameo的行数，循环
    event_num[num_cameo[ii]] = 0 #initial

for ii in range(len(event)):#新闻事件数循环
    #event[ii]
    for jj in range(len(num_cameo)):#地区数循环
        if event[ii][7]==num_cameo[jj]: # or [1x]==num_cameo[jj]，第七项是地区
            event_num[num_cameo[jj]] += 1#统计有没有地区在新闻里出现，出现加一

###end
print(event_num)
b = input('选择要查询的地点 如（Moscow China Canada）')
b= (str)(b)
for ii in range(len(event)):
    event[ii][36]=(str)(event[ii][36])
    if event[ii][36]==b:
        print(event[ii])





