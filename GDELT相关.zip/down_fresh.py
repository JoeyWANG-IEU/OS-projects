import requests #爬虫使用的requests模块
import zipfile#处理压缩文件的模块
import csv#python自带的处理csv文件的模块
import urllib.request#urllib库中的urllib.request 请求模块
import time
import os
import sys

start = 1
i = 0
end = 0
f = open('./date.txt',mode='r+',encoding='UTF-8')
e_end = f.read()
e_end = (int)(e_end)
f.close
#print(e_end)
i = input('选择要使用的功能\n1:手动下载数据包\n2:主动更新（从2019.11.05之后开始）：')
print(i)
i = (int)(i)
if (i==1) :
    start = input("input start date")#要获得数据的时间段
    end = input ("input end data")
    start = (int)(start)#强制类型转换
    end = (int)(end)
else:
    start = e_end
    s = time.strftime('%Y%m%d', time.localtime(time.time()))
    end = (int)(s[0] + s[1] + s[2] + s[3] + s[4] + s[5] + s[6] + s[7])
   # print(end,e_end)
    if(end==e_end):
        print('已经是最新的数据库！！！')
        os._exit(0)
    f=open('./date.txt','w')
    f.write(str(end))
    f.close
    #print(end,e_end)

for ii in range(start,end):  #左开右闭
    print(ii)
    date = (str)(ii)#日期由int型转换成字符串
    name0 = date+".export.CSV"
    name = date+".export.CSV.zip"
    addr = "http://data.gdeltproject.org/events/"+ name#定位到网页链接
#    f = requests.get(addr)#向服务器发送请求
#    with open(name,'wb') as code:
#        code.write(f.content)#f.content是字节方式的响应体，会自动解码 gzip 和 deflate 压缩，将f.content写入
#下载效率偏低
    f = urllib.request.urlopen(addr)#用于实现对目标url的访问，打开和浏览url中内容 
    data = f.read()#对HTTPResponse类型数据进行操作，从文件当前位置起读取至文件结束为止，它范围为字符串对象，
    with open(name, "wb") as code:#以二进制写方式打开，只能写文件， 如果文件不存在，创建该文件；如果文件已存在，先清空，再打开文件，文件名是name
        code.write(data)

    print("download ok")

    f = zipfile.ZipFile(name)#创建一个ZipFile对象，表示一个zip文件。默认值为'r'，表示读已经存在的zip文件。
    for file in f.namelist():#f.namelist()返回列表，列表中的元素为压缩文件中的每个文件
        f.extract(file,"./data/")#循环访问该压缩文件中的文件，并且一个一个file的解压到对应的"./data/"文件夹中
    print("unzip ok")

    path = "./data/" + name0
    file = open(path, "r")#以只读方式打开文件
    reader = csv.reader(file)#读file返回一个reader对象，利用该对象遍历csv文件中的行
    #CSV是一种以逗号分隔数值的文件类型，在数据库或电子表格中，常见的导入导出文件格式就是CSV格式，CSV格式存储数据通常以纯文本的方式存数数据表。

    event = []#创建空的event
    for row in reader:#逐行写入
        # every row
        event.append(row)#append函数加进后续的元素

    new_event = []#创建新的空列表
    for ii in range(len(event)):# 行数：以列表的元素个数创建一个新的整数列表用在for循环，range()是python内置函数它能返回一系列连续增加的整数
        temp_event = []#创建新的空列表
        for jj in range(len(event[ii])):#列数：循环
            temp_event += event[ii][jj].split('\t')# 通过指定分隔符对字符串进行切片，这里是水平制表符，字符串间隔=8-（len(上一个字符串)%8）
        new_event.append(temp_event)#append函数加进后续的元素

    new_name = "n_" + name0
    path = "./n_data/" + new_name
    fn = open(path, "w", newline='')#打开一个文件只用于写入，"newline="就是说因为我们的csv文件的类型，如果不加这个东西，当我们写入东西的时候，就会出现空行，
    writer = csv.writer(fn)#创建一个写的对象writer

    for ii in range(len(new_event)):
        writer.writerow(new_event[ii])#逐行写入

    print("fresh ok")
    fn.close()
    file.close()
