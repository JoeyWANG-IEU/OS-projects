import csv
import sys
import os
import numpy as np
import time
import datetime
import matplotlib.pyplot as plt
import skccm as ccm
import skccm.data as data
from skccm.utilities import train_test_split
import xlwt

#综合国力排名前十  --维基百科
#Cameo = ['USA','CHN','IND','JPN','RUS','PHL','KOR','PRK','SYR','GBR']
##final_out = open('out.csv',"a",newline = '')
##final_writer = csv.writer(final_out)
wb = xlwt.Workbook()
ws1 = wb.add_sheet('sc1')
ws2 = wb.add_sheet('sc2')




Cameo = {}
num_cameo = []
a = 0
file = 'name.txt'
fn = open(file,"r")
for row in fn.readlines():
    row = row.split()
    Cameo[row[0]]=a
    num_cameo.append(row[0])
    a += 1




for j in range(200,219):
    source = Cameo[j]

    for i in range(len(Cameo)):
        target = Cameo[i]
        if i == j:
            continue
        
        #脚本
##        filename= source + '.csv'
##        f = open(filename,"r")
##        reader = csv.reader(f)
##
##        new = 'n'+ source + '_' + target + '.csv'
##        fn = open(new,"a",newline='')
##        writer = csv.writer(fn)
##
##        x1 = np.array([0])
##        x2 = np.array([0])
##
##        a = 0
##        head_a = 0
##        for row in reader:
##            if str(row[1]).strip()[:3] == source and str(row[2]).strip()[:3] == target:
##                if head_a == 0:
##                    head_a+=1
##                    continue
##                if a ==0:
##                    a+=1
##                    temp = row[0]
####                    x1 = np.append(x1,0)
####                    x2 = np.append(x2,0)
##                if row[0] != temp:
##                    writer.writerow([temp,x1[-1],x2[-1]])
##                    x1 = np.append(x1,0)
##                    x2 = np.append(x2,0)
##                    temp = row[0]
##                if str(row[3]) == '1':
##                    x1[-1]+=1
##                elif row[3] == '2':
##                    x2[-1]+=1
##        writer.writerow([temp,x1[-1],x2[-1]])
##
##        f.close()
##        fn.close()
##
##        #日期填充
##        filename = 'n'+ source + '_' + target + '.csv'
##        f = open(filename,"r")
##        reader = csv.reader(f)
##
##        nfile = source + '_' + target + '.csv'
##        fn  = open(nfile,"a",newline='')
##        writer = csv.writer(fn)
##
##        temp_date = datetime.datetime(2014,1,1)
##        end = datetime.datetime(2018,1,1)
##
##        a = 0
##        for row in reader:
##               temp = str(temp_date.year)+str(temp_date.month).zfill(2)+str(temp_date.day).zfill(2)
##               while row[0]>temp:
##                      print(row[0])
##                      #print(temp)
##                      temp = str(temp_date.year)+str(temp_date.month).zfill(2)+str(temp_date.day).zfill(2)
##                      writer.writerow([temp,0,0])
##                      temp_date += datetime.timedelta(days=1)
##               writer.writerow(row)
##               temp_date += datetime.timedelta(days=1)
##        print("ok")
##        fn.close()
##        f.close()

        #计算ccm
        filename1 = source + '_' + target + '.csv'
        if not os.path.exists(filename):
               ws2.write(j,i,-1)
               continue
        f = open(filename,"r")
        reader = csv.reader(f)
        x1 = np.array([])
        x2 = np.array([])
        a = 0
        for row in reader:
            x1 = np.append(x1,row[1])
            x2 = np.append(x2,row[2])
        print("LOAD ok")
        print(len(x1))
        ##fig,ax = plt.subplots(nrows=2,sharex=True,sharey=True)
        ##ax[0].plot(x1[0:100])
        ##ax[1].plot(x2[0:100])
        ##ax[1].set_xlabel('Time')
        ##sns.despine()
        ##plt.show()
        
        ##if len(x1)<365 or len(x2)<365:
        ##       continue

        lag = 30
        embed = 9

        e1 = ccm.Embed(x1)
        e2 = ccm.Embed(x2)
        X1 = e1.embed_vectors_1d(lag,embed)
        X2 = e2.embed_vectors_1d(lag,embed)
        #plt.plot(X1[0:50])
        #plt.show()




        #split the embedded time series
        x1tr, x1te, x2tr, x2te = train_test_split(X1,X2, percent=.75)

        CCM = ccm.CCM() #initiate the class

        #library lengths to test
        len_tr = len(x1tr)
        lib_lens = np.arange(20, len_tr, len_tr/20, dtype='int')

        #test causation
        CCM.fit(x1tr,x2tr)
        x1p, x2p = CCM.predict(x1te, x2te,lib_lengths=lib_lens)

        sc1,sc2 = CCM.score()
        print(sc1[-1])
        print(sc2[-1])
        if sc1[-1] > -1 and sc1[-1]<1:
            ws1.write(j,i,sc1[-1])
        else:
            ws1.write(j,i,-1)
        if sc2[-1] > -1 and sc2[-1]<1:
            ws2.write(j,i,sc2[-1])
        else:
            ws2.write(j,i,-1)
        #final_writer.writerow([source,target,sc1[-1],sc2[-1]])
        f.close()
##        os.remove( 'n'+ source + '_' + target + '.csv')
        print("one time ok"+str(j)+'&&'+str(i))

##final_out.close()
wb.save('final_out.xls')
