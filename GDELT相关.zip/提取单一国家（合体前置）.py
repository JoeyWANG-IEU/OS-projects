#保存某国信用数据，方便读取
import csv
import sys
import datetime
import os

Cameo = ['USA','CHN','IND','JPN','RUS','PHL','KOR','PRK','SYR','GBR']

for i in range(5,6):
       na = Cameo[i]
              
       for j in range(2016,2017):
              temp = datetime.datetime(j,4,1)
              end = datetime.datetime(j+1,4,1)
              file1 = 'E:/1/'+str(j%100) + str(j%100 +1 )+ '/'
              newfile = na +'.csv'
              fn = open(newfile,"a",newline='')
              writer = csv.writer(fn)
              name2 = '.csv'

              while temp<end:
                  #字符串数字自动补零！！！！
                  temp_name=str(temp.year)+str(temp.month).zfill(2)+str(temp.day).zfill(2)
                  filename=file1+temp_name+name2
                  try:
                      f = open(filename,"r")
                  except:
                      print("open error at"+filename)
                      temp +=datetime.timedelta(days = 1)
                      continue
                  reader = csv.reader(f)

                  for row in reader:
                      if row[7].strip()[:3] == na :
                          writer.writerow([row[1],row[7].strip(),row[17].strip(),row[29]])
                  f.close()
                  print(temp_name)
                  temp +=datetime.timedelta(days = 1)
              fn.close()
              print("LOAD ok")
